<?php

define( 'WP_DEBUG', true );

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

error_reporting(E_ALL);

define( 'WPLIB_BOX_URL_SCHEME', 'http' );