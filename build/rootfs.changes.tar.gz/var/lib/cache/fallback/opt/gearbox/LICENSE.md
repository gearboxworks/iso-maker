#License for github.com/gearboxworks/box-scripts

Box Scripts for GearBox is free to use with absolutely no warranty.

However Box Scripts for GearBox is currently NOT open-source and thus not free to distribute.

Although we strong believe in open-source software, we choose this approach _at this time_
to protect ourselves against a [WooCommercing](https://yoast.com/open-source-forking-branding/) 
of our project while we are still early and trying to build our brand.

Copyright 2016-2018 NewClarity Consulting LLC, All Rights Reserved Worldwide
