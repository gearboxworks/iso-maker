This holds all the CLI based commands and utilities.
