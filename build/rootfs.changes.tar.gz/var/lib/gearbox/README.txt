# This directory exists for the sole purpose of storing dynamic states, variables, or things that change only within the context of a specific boot of the Gearbox OS.
# It can be considered active runtime states / variables that ONLY apply to the general OS runtime.
# Any Gearbox specific states/variables are contained elsewhere.

# Current information stored here:

