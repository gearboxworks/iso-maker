```
 __          _______  _      _ _       ____
 \ \        / /  __ \| |    (_) |     |  _ \
  \ \  /\  / /| |__) | |     _| |__   | |_) | _____  __
   \ \/  \/ / |  ___/| |    | | '_ \  |  _ < / _ \ \/ /
    \  /\  /  | |    | |____| | |_) | | |_) | (_) >  <
     \/  \/   |_|    |______|_|_.__/  |____/ \___/_/\_\
```

![GearBox](https://github.com/wplib/box-scripts/blob/master/GearBox-100x.png)

# W020 - 500 Internal Server Error.

## Cause
There is an issue with the PHP code running on GearBox.

## Common fixes
Check for files and plugins that may have been added or modified since it was working last.

### 


## See Also
[Complete Error code repository for GearBox](https://github.com/wplib/box-scripts/tree/master/docs/errors)

